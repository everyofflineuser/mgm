# Login with Discord Python Example Server
### ⚠️This server implementation is only an example and is not intended for use in production.

## Dependencies
- Python 3
- Flask 2.2.3
- requests 2.28.2

## How to use
1. `pip install -r requirements.txt`
1. `python Server.py`
1. Open the "5. Login with Server Side Validation" Scene
1. Login with your Discord account