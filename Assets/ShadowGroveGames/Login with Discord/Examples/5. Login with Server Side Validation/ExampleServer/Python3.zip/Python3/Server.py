import os
import datetime
import requests
from flask import Flask, request, url_for, jsonify

API_BASE_URL = 'https://discord.com/api/v10'

app = Flask(__name__)

def discordRequest(endpoint, accessToken):
    return requests.get(API_BASE_URL + endpoint, headers={"Authorization":"Bearer " + accessToken})

@app.route('/', methods=['POST'])
def index():
    jsonBody = request.get_json()
    response = discordRequest("/users/@me", jsonBody["AccessToken"]).json()
    response["welcomeMessage"] = "Hello and welcome {}#{} with Id: {} to the Python Example Server.\n<color=yellow>The Server Time is: {}</color>".format(
        response["username"],
        response["discriminator"],
        response["id"],
        datetime.datetime.now()
    )
    return jsonify(response)
    
    
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=17791)