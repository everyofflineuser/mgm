<?php
declare(strict_types=1);

namespace ShadowGroveGames\LoginWithDiscordExampleServer;

final class LoginWithDiscordServerProcessor
{
    private ?SimpleDiscordApiClient $apiClient = null;

    /**
     * A example server side processing of discord data
     * which append a welcome message to the userInformation
     */
    public function process()
    {
        $accessToken = $this->getAccessToken();
        if ($accessToken === null) {
            // Bad Request
            http_response_code(400);
            return;
        }

        $this->createApiClient($accessToken);

        $userInformation = $this->getUserInformation();
        if ($userInformation === null) {
            // Not authorized
            http_response_code(401);
            return;
        }

        $processedUserInformation = $this->appendServerInformation($userInformation);

        header('Content-Type: application/json');
        echo json_encode($processedUserInformation);
    }

    /**
     * Get accessToken from http post body
     */
    private function getAccessToken(): ?string
    {
        $jsonBody = file_get_contents('php://input');

        if (empty($jsonBody)) {
            return null;
        }

        $requestData = json_decode($jsonBody, true);

        if (empty($requestData['AccessToken'] ?? null) || !is_string($requestData['AccessToken'])) {
            return null;
        }

        return $requestData['AccessToken'];
    }

    /**
     * Create a simple api client which communicate with the discord api
     */
    private function createApiClient(string $accessToken): void
    {
        $this->apiClient = new SimpleDiscordApiClient($accessToken);
    }

    /**
     * Get and validate user information
     */
    private function getUserInformation(): ?array
    {
        try {
            $userInformation = $this->apiClient->getUserInformation();
        } catch (\Throwable $exception)
        {
            return null;
        }

        if (empty($userInformation['id']) || empty($userInformation['username']) || empty($userInformation['discriminator'])) {
            return null;
        }

        return $userInformation;
    }

    /**
     * Append a simple welcome message to the user information
     */
    private function appendServerInformation(array $userInformation): array
    {
        $userInformation['welcomeMessage'] = sprintf(
            "Hello and welcome %s#%s with Id: %s to the PHP Example Server.\n<color=yellow>The Server Time is: %s</color>",
            $userInformation['username'],
            $userInformation['discriminator'],
            $userInformation['id'],
            (new \DateTimeImmutable())->format('Y-m-d H:i:s')
        );

        return $userInformation;
    }
}