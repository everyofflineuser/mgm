<?php
declare(strict_types=1);

namespace ShadowGroveGames\LoginWithDiscordExampleServer;

final class SimpleDiscordApiClient
{
    private string $accessToken;

    public function __construct(string $accessToken)
    {
        $this->accessToken = $accessToken;
    }

    /**
     * Get user information from discord api
     */
    public function getUserInformation(): array
    {
        return $this->sendRequest('/users/@me');
    }

    /**
     * Get list of all guilds the user is in
     */
    public function getUserGuilds(): array
    {
        return $this->sendRequest('/users/@me/guilds');
    }

    /**
     * Get membership information for a specific guild
     */
    public function getGuildMember(int $guildId): array
    {
        return $this->sendRequest(sprintf('/users/@me/guilds/%u/member', $guildId));
    }

    /**
     * Get a list of all third party accounts
     */
    public function getUserConnections(): array
    {
        return $this->sendRequest('/users/@me/connections');
    }

    /**
     * Send requests to discord api
     */
    private function sendRequest(string $endPoint): array
    {
        $curl = curl_init(sprintf('https://discord.com/api/v10/%s', trim($endPoint, '/')));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $this->accessToken
        ));

        $response = curl_exec($curl);

        return json_decode($response, true);
    }
}