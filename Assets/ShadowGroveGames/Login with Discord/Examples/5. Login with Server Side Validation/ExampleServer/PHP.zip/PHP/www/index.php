<?php
declare(strict_types=1);

use ShadowGroveGames\LoginWithDiscordExampleServer\LoginWithDiscordServerProcessor;

require_once __DIR__ . '/../vendor/autoload.php';

$loginWithDiscordServerProcessor = new LoginWithDiscordServerProcessor();
$loginWithDiscordServerProcessor->process();