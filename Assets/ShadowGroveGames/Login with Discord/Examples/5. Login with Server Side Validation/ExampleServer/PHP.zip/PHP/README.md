# Login with Discord PHP Example Server
### ⚠️This server implementation is only an example and is not intended for use in production.

## Dependencies
- PHP 7.4 or later

## How to use
1. Open a Terminal in the "www" folder
1. Type the command `php -S 127.0.0.1:17791`
1. Open the "5. Login with Server Side Validation" Scene
1. Login with your Discord account