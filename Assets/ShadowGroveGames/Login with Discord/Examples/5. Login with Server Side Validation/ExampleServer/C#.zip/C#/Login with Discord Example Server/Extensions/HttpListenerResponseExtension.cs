﻿using Newtonsoft.Json;
using System.Net;
using System.Text;

namespace ShadowGroveGames.LoginWithDiscord.ExampleServer.Extensions
{
    public static class HttpListenerResponseExtension
    {

        public static void JsonResponse<T>(this HttpListenerResponse response, T data, Formatting formatting = Formatting.Indented, JsonSerializerSettings? settings = null)
        {
            string json = JsonConvert.SerializeObject(data, formatting, settings);

            WriteUTF8TextToResponseBody(response, json, "application/json; charset=utf-8");
        }

        public static void WriteUTF8TextToResponseBody(HttpListenerResponse response, string text, string contentType)
        {
            Stream stream = new MemoryStream(Encoding.UTF8.GetBytes(text));
            response.ContentEncoding = Encoding.UTF8;

            StreamResponse(response, stream, contentType);
        }

        public static void StreamResponse(this HttpListenerResponse response, Stream stram, string contentType = "application/octet-stream")
        {
            response.ContentType = contentType;
            response.ContentLength64 = stram.Length;

            byte[] buffer = new byte[1024 * 16];
            int byteCount;

            while ((byteCount = stram.Read(buffer, 0, buffer.Length)) > 0)
                response.OutputStream.Write(buffer, 0, byteCount);


            stram.Close();
            response.OutputStream.Flush();
            response.OutputStream.Close();
            response.Close();
        }
    }
}
