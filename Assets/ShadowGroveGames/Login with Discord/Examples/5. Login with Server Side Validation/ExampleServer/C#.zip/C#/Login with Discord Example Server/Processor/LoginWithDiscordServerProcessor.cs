﻿using Newtonsoft.Json;
using ShadowGroveGames.LoginWithDiscord.ExampleServer.DTO;
using ShadowGroveGames.LoginWithDiscord.ExampleServer.Extensions;
using ShadowGroveGames.LoginWithDiscordClient;
using ShadowGroveGames.LoginWithDiscordClient.DTO;
using System.Net;

namespace ShadowGroveGames.LoginWithDiscord.ExampleServer.Processor
{
    class LoginWithDiscordServerProcessor
    {
        public void Process(HttpListenerRequest request, HttpListenerResponse response)
        {
            var oAuthToken = request.GetJsonBody<OAuthToken>();
            if (oAuthToken == null || string.IsNullOrEmpty(oAuthToken.Value.AccessToken))
            {
                // Invalid request!
                response.StatusCode = 400;
                Console.WriteLine("[WARNING] Invalid request body!");
                return;
            }

            var discordClient = new DiscordClient(oAuthToken.Value);
            var discordUser = discordClient.GetUser();

            if (!discordUser.HasValue)
            {
                response.StatusCode = 500;
                Console.WriteLine("[ERROR] Cant fetch data from discord API!");
                return;
            }

            var serverSideUser = new ServerSideUser()
            {
                Id = discordUser.Value.Id,
                Username = discordUser.Value.Username,
                Discriminator = discordUser.Value.Discriminator,
                AvatarHash = discordUser.Value.AvatarHash,
                IsBotUser = discordUser.Value.IsBotUser,
                IsSystemUser = discordUser.Value.IsSystemUser,
                AvatarDecorationHash = discordUser.Value.AvatarDecorationHash,
                PublicFlags = discordUser.Value.PublicFlags,
                Flags = discordUser.Value.Flags,
                BannerHash = discordUser.Value.BannerHash,
                BannerColor = discordUser.Value.BannerColor,
                AccentColor = discordUser.Value.AccentColor,
                Locale = discordUser.Value.Locale,
                MFA = discordUser.Value.MFA,
                PremiumType = discordUser.Value.PremiumType,
                Verified = discordUser.Value.Verified,
                WelcomeMessage = $"Hello and welcome {discordUser.Value.Username}#{discordUser.Value.Discriminator} with Id: {discordUser.Value.Id} to the C# Example Server.\n<color=yellow>The Server Time is: {DateTime.Now}</color>"
            };

            response.StatusCode = 200;
            response.JsonResponse(serverSideUser, Formatting.Indented, new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            });
        }
    }
}
