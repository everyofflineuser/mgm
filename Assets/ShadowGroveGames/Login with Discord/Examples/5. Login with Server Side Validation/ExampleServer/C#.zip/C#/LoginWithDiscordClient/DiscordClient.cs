using Newtonsoft.Json;
using ShadowGroveGames.LoginWithDiscordClient.DTO;
using ShadowGroveGames.LoginWithDiscordClient.DTO.Discord;
using ShadowGroveGames.LoginWithDiscordClient.Exceptions;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;

#nullable enable
namespace ShadowGroveGames.LoginWithDiscordClient
{
    public class DiscordClient
    {
        private const string BASE_URL = "https://discord.com";
        private const string API_PATH = "/api/v10/";

        private OAuthToken _oAuthToken;
        private HttpClient _httpClient;

        public DiscordClient(OAuthToken oAuthToken)
        {
            _oAuthToken = oAuthToken;
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri(BASE_URL);
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(_oAuthToken.TokenType, _oAuthToken.AccessToken);
            _httpClient.Timeout = TimeSpan.FromSeconds(5);
        }

        public User? GetUser()
        {
            if (!_oAuthToken.Scope.Contains(OAuthPermissions.USER))
                throw new InsufficientPermissionsException("You do not have access to user information. Request this permission before calling this method.");

            var responseBody = SendGetRequest("/users/@me");
            if (responseBody == null)
                return null;

            return JsonConvert.DeserializeObject<User>(responseBody);
        }

        public List<UserGuild>? GetUserGuilds()
        {
            if (!_oAuthToken.Scope.Contains(OAuthPermissions.GUILDS))
                throw new InsufficientPermissionsException("You do not have access to guilds information. Request this permission before calling this method.");

            var responseBody = SendGetRequest("/users/@me/guilds");
            if (responseBody == null)
                return null;

            return JsonConvert.DeserializeObject<List<UserGuild>>(responseBody);
        }

        public GuildMember? GetGuildMember(ulong guildId)
        {
            if (!_oAuthToken.Scope.Contains(OAuthPermissions.GUILD_MEMBER))
                throw new InsufficientPermissionsException("You do not have access to member information of a specific guild the user is in. Request this permission before calling this method.");

            var responseBody = SendGetRequest($"/users/@me/guilds/{guildId}/member");
            if (responseBody == null)
                return null;

            var guildMember = JsonConvert.DeserializeObject<GuildMember>(responseBody);
            guildMember.GuildId = guildId;

            return guildMember;
        }

        public List<UserConnection>? GetUserConnections()
        {
            if (!_oAuthToken.Scope.Contains(OAuthPermissions.CONNECTIONS))
                throw new InsufficientPermissionsException("You do not have access to linked third-party accounts. Request this permission before calling this method.");

            var responseBody = SendGetRequest("/users/@me/connections");
            if (responseBody == null)
                return null;

            return JsonConvert.DeserializeObject<List<UserConnection>>(responseBody);
        }

        private string? SendGetRequest(string url)
        {
            if (_oAuthToken.IsExpired)
            {
                Console.WriteLine("[ERROR] Discord OAuth token is expired!");
                return null;
            }

            url = API_PATH + url.Trim().Trim('/');

            try
            {
                var response = _httpClient.SendAsync(new HttpRequestMessage(HttpMethod.Get, BASE_URL + url)).Result;
                if (!response.IsSuccessStatusCode)
                    throw new Exception("Request Error!");

                var contentBody = response.Content.ReadAsStringAsync().Result;

                if (string.IsNullOrEmpty(contentBody))
                    throw new ArgumentNullException("Response from discord api is null!");

                return contentBody;
            }
            catch (Exception ex)
            {
                Console.WriteLine("[Exception] {0}", ex);
            }

            return null;
        }
    }
}
#nullable disable