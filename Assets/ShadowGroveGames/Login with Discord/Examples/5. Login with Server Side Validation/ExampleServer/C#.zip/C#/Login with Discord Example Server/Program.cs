﻿using ShadowGroveGames.LoginWithDiscord.ExampleServer;

Console.WriteLine("== Login with Discord C# Example Server ==");
Console.WriteLine("This server is only an example and is not intended for use in a production environment!\n");

var server = new Server();
server.Start();

Console.WriteLine("Press Ctrl + C to close the server");

