﻿using Newtonsoft.Json;
using System;
using System.Drawing;

namespace ShadowGroveGames.LoginWithDiscordClient.DTO.Converter
{
    public class IntegerToColorConverter : JsonConverter<Color>
    {
        public override void WriteJson(JsonWriter writer, Color value, JsonSerializer serializer)
        {
            serializer.Serialize(writer, long.Parse(ColorTranslator.ToHtml(value).Replace("#", ""), System.Globalization.NumberStyles.HexNumber));
        }

        public override Color ReadJson(JsonReader reader, Type objectType, Color existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            if (reader.Value == null)
                return Color.White;

            int intColor = int.Parse(reader.Value.ToString());
            string hexColor = String.Format("#{0:X6}", 0xFFFFFF & intColor).ToUpper();

            return ColorTranslator.FromHtml(hexColor);

        }
    }
}
