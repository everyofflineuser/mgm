using Newtonsoft.Json;
using ShadowGroveGames.LoginWithDiscordClient.DTO.Common.Flags;
using ShadowGroveGames.LoginWithDiscordClient.DTO.Converter;
using System.Drawing;

#nullable enable
namespace ShadowGroveGames.LoginWithDiscord.ExampleServer.DTO
{
    public struct ServerSideUser
    {
        /// <summary>
        /// The user's id
        /// </summary>
        [JsonProperty("id")]
        public ulong Id;

        /// <summary>
        /// The user's username, not unique across the platform
        /// </summary>
        [JsonProperty("username")]
        public string Username;

        /// <summary>
        /// The user's 4-digit discord-tag
        /// </summary>
        [JsonProperty("discriminator")]
        public string Discriminator;

        /// <summary>
        /// The user's avatar hash
        /// </summary>
        [JsonProperty("avatar")]
        public string AvatarHash;

        /// <summary>
        /// Whether the user belongs to an OAuth2 application
        /// </summary>
        [JsonProperty("bot")]
        public bool? IsBotUser;

        /// <summary>
        /// Whether the user is an Official Discord System user (part of the urgent message system)
        /// </summary>
        [JsonProperty("system")]
        public bool? IsSystemUser;

        /// <summary>
        /// The user's avatar decoration hash
        /// </summary>
        [JsonProperty("avatar_decoration", NullValueHandling = NullValueHandling.Include)]
        public string? AvatarDecorationHash;

        /// <summary>
        /// The public flags on a user's account
        /// </summary>
        [JsonProperty("public_flags")]
        public UserFlags? PublicFlags;

        /// <summary>
        /// The flags on a user's account
        /// </summary>
        [JsonProperty("flags")]
        public UserFlags? Flags;

        /// <summary>
        /// The user's banner hash
        /// </summary>
        [JsonProperty("banner", NullValueHandling = NullValueHandling.Include)]
        public string? BannerHash;

        /// <summary>
        /// The user's banner color
        /// </summary>
        [JsonProperty("banner_color"), JsonConverter(typeof(HexToColorConverter))]
        public Color? BannerColor;

        /// <summary>
        /// The user's banner color
        /// </summary>
        [JsonProperty("accent_color"), JsonConverter(typeof(IntegerToColorConverter))]
        public Color? AccentColor;

        /// <summary>
        /// The user's chosen language option
        /// </summary>
        [JsonProperty("locale")]
        public string? Locale;

        /// <summary>
        /// Whether the user has two factor enabled on their account
        /// </summary>
        [JsonProperty("mfa_enabled")]
        public bool? MFA;

        /// <summary>
        /// The type of Nitro subscription on a user's account
        /// </summary>
        [JsonProperty("premium_type")]
        public PremiumFlags? PremiumType;

        /// <summary>
        /// Whether the email on this account has been verified
        /// </summary>
        [JsonProperty("verified")]
        public bool? Verified;

        /// <summary>
        /// The user's email
        /// </summary>
        [JsonProperty("email")]
        public string? Email;

        /// <summary>
        /// Server side welcome message
        /// </summary>
        [JsonProperty("welcomeMessage")]
        public string WelcomeMessage;
    }
}
#nullable disable