﻿using ShadowGroveGames.LoginWithDiscord.ExampleServer.Processor;
using System.Net;
using System.Net.Sockets;

namespace ShadowGroveGames.LoginWithDiscord.ExampleServer
{
    public class Server
    {
        private HttpListener _listener;
        private Thread _listenerThread;
        private LoginWithDiscordServerProcessor _processor;

        public Server()
        {
            _listener = new HttpListener();
            _listener.AuthenticationSchemes = AuthenticationSchemes.Anonymous;
            _listener.Prefixes.Add("http://127.0.0.1:17791/");

            _processor = new LoginWithDiscordServerProcessor();
        }

        /// <summary>
        /// Start the listener
        /// </summary>
        /// <returns>Returns false if no listening address was added.</returns>
        public bool Start()
        {
            try
            {
                _listener.Start();
            }
            catch (SocketException ex)
            {
                Console.WriteLine($"Listener ports are already used!\n{string.Join(" | ", _listener.Prefixes)}");
                Console.WriteLine(ex);
                return false;
            }

            _listenerThread = new Thread(ListenerLoop);
            _listenerThread.Start();

            Console.WriteLine("Listener started: http://127.0.0.1:17791/");

            return true;
        }

        private void ListenerLoop()
        {
            while (true)
            {
                // Will wait here until we hear from a connection
                HttpListenerContext context = _listener.GetContext();
                HttpListenerRequest request = context.Request;
                HttpListenerResponse response = context.Response;

                try
                {
                    Console.WriteLine($"[{request.HttpMethod}] {request.Url.LocalPath}");
                    response.StatusCode = 404;

                    if (request.HttpMethod == "POST" && request.Url.LocalPath == "/")
                        _processor.Process(request, response);

                }
                catch (Exception ex)
                {
                    response.StatusCode = 500;
                    Console.WriteLine(ex);
                }

                response.Close();
            }
        }
    }
}
