# Login with Discord C# Example Server
### ⚠️This server implementation is only an example and is not intended for use in production.

## Dependencies
- Visual Studio

## How to use
1. Open the "Login with Discord Example Server.sln
1. Run the Project
1. Open the "5. Login with Server Side Validation" Scene
1. Login with your Discord account