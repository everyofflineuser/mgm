namespace ShadowGroveGames.LoginWithDiscordClient.DTO
{
    public struct OAuthPermissions
    {
        public const string USER = "identify";
        public const string USER_WITH_EMAIL = "email";
        public const string GUILDS = "guilds";
        public const string GUILD_MEMBER = "guilds.members.read";
        public const string CONNECTIONS = "connections";
    }
}
