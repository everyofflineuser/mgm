namespace ShadowGroveGames.LoginWithDiscordClient.DTO.Common.Flags
{
    public enum IntegrationServiceType
    {
        BATTLENET,
        EBAY,
        EPICGAMES,
        FACEBOOK,
        GITHUB,
        LEAGUEOFLEGENDS,
        PAYPAL,
        PLAYSTATION,
        REDDIT,
        RIOTGAMES,
        SPOTIFY,
        SKYPE,
        STEAM,
        TIKTOK,
        TWITCH,
        TWITTER,
        XBOX,
        YOUTUBE
    }
}
