﻿using System;

namespace ShadowGroveGames.LoginWithDiscordClient.Exceptions
{
    public class InsufficientPermissionsException : UnauthorizedAccessException
    {
        public InsufficientPermissionsException(string message) : base(message)
        {
        }
    }
}
